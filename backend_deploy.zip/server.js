console.log("Starting server.js...");
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '.env') });
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const Stripe = require('stripe');

// Models
const User = require('./models/User');
const Contact = require('./models/Contact');
const Book = require('./models/Book');
const Order = require('./models/Order');

// Routes Imports
const phonePeRoutes = require('./routes/phonepe');
const adminRoutes = require('./routes/admin');
const authMiddleware = require('./middleware/auth');
const upload = require('./middleware/upload');

const app = express();
const PORT = process.env.PORT || 5000;
const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

// --- MIDDLEWARE ---
const clientUrl = process.env.CLIENT_URL || 'http://localhost:5173';
app.use(cors({
    origin: true, // Allow all for debugging
    credentials: true
}));
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads'))); // Serve images

// --- DATABASE & SEEDING ---
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/bookverse';

const initialBooks = [
    { id: 1, title: "The Great Gatsby", author: "F. Scott Fitzgerald", price: 999, genre: "Fiction", image: "https://placehold.co/400x600/F87171/white?text=Great+Gatsby", rating: 4.5, reviews: 120, buyLink: "https://amazon.com/dp/B000FC0R0W" },
    { id: 2, title: "1984", author: "George Orwell", price: 850, genre: "Sci-Fi", image: "https://placehold.co/400x600/60A5FA/white?text=1984", rating: 4.8, reviews: 350 },
    { id: 3, title: "Dune", author: "Frank Herbert", price: 1450, genre: "Sci-Fi", image: "https://placehold.co/400x600/FBBF24/white?text=Dune", rating: 4.9, reviews: 410 },
    { id: 4, title: "Pride and Prejudice", author: "Jane Austen", price: 799, genre: "Classic", image: "https://placehold.co/400x600/34D399/white?text=Pride+Prejudice", rating: 4.6, reviews: 200 },
    { id: 5, title: "The Hobbit", author: "J.R.R. Tolkien", price: 1200, genre: "Fantasy", image: "https://placehold.co/400x600/A78BFA/white?text=The+Hobbit", rating: 5.0, reviews: 500 },
    { id: 6, title: "Sapiens", author: "Yuval Noah Harari", price: 1750, genre: "History", image: "https://placehold.co/400x600/F472B6/white?text=Sapiens", rating: 4.7, reviews: 180 },
    { id: 7, title: "Thinking, Fast and Slow", author: "Daniel Kahneman", price: 1100, genre: "Non-Fiction", image: "https://placehold.co/400x600/FCD34D/white?text=Thinking+Fast", rating: 4.6, reviews: 300 },
    { id: 8, title: "A Brief History of Time", author: "Stephen Hawking", price: 950, genre: "Science", image: "https://placehold.co/400x600/60A5FA/white?text=Brief+History", rating: 4.8, reviews: 450 },
    { id: 9, title: "Silent Spring", author: "Rachel Carson", price: 890, genre: "Non-Fiction", image: "https://placehold.co/400x600/34D399/white?text=Silent+Spring", rating: 4.4, reviews: 150 },
    { id: 10, title: "External Link Demo", author: "Demo User", price: 0, genre: "Non-Fiction", image: "https://placehold.co/400x600/ccc/white?text=External+Link", rating: 5.0, reviews: 0, buyLink: "https://google.com" },

    // NEW BOOKS (Non-Fiction)
    { id: 11, title: "Atomic Habits", author: "James Clear", price: 650, genre: "Non-Fiction", image: "https://placehold.co/400x600/ef4444/white?text=Atomic+Habits", rating: 4.9, reviews: 800 },
    { id: 12, title: "Educated", author: "Tara Westover", price: 720, genre: "Non-Fiction", image: "https://placehold.co/400x600/f59e0b/white?text=Educated", rating: 4.7, reviews: 600 },
    { id: 13, title: "Becoming", author: "Michelle Obama", price: 900, genre: "Non-Fiction", image: "https://placehold.co/400x600/3b82f6/white?text=Becoming", rating: 4.8, reviews: 1000 },

    // NEW BOOKS (Fiction)
    { id: 14, title: "The Alchemist", author: "Paulo Coelho", price: 499, genre: "Fiction", image: "https://placehold.co/400x600/eab308/white?text=Alchemist", rating: 4.8, reviews: 900 },
    { id: 15, title: "Harry Potter", author: "J.K. Rowling", price: 1200, genre: "Fantasy", image: "https://placehold.co/400x600/ec4899/white?text=Harry+Potter", rating: 4.9, reviews: 2000 },
    { id: 16, title: "The Catcher in the Rye", author: "J.D. Salinger", price: 550, genre: "Fiction", image: "https://placehold.co/400x600/6366f1/white?text=Catcher+Rye", rating: 4.2, reviews: 400 }
];

async function seedDatabase() {
    try {
        const count = await Book.countDocuments();
        if (count < initialBooks.length) {
            console.log('🌱 Database missing some data. Seeding/Updating books...');
            await Book.deleteMany({});
            await Book.insertMany(initialBooks);
            console.log('✅ Books seeded successfully!');
        } else {
            console.log(`ℹ️ Database has ${count} books. checks passed.`);
        }
    } catch (err) {
        console.error('❌ Error seeding database:', err);
    }
}

async function seedAdmin() {
    try {
        const adminEmail = "admin@bookverse.com";
        const existingAdmin = await User.findOne({ email: adminEmail });
        if (!existingAdmin) {
            const newAdmin = new User({
                name: "Admin User",
                email: adminEmail,
                password: "admin123", // In a real app, hash this!
                role: "admin"
            });
            await newAdmin.save();
            console.log("👑 Default Admin Created: admin@bookverse.com / admin123");
        }
    } catch (err) {
        console.error("Admin Seed Error:", err);
    }
}

mongoose.connect(MONGO_URI)
    .then(async () => {
        console.log('✅ MongoDB Connected');
        await seedDatabase();
        await seedAdmin();
    })
    .catch(err => {
        console.error('❌ MongoDB Connection Error:', err);
    });

// --- ROUTES ---

// App Routes
app.use('/api/phonepe', phonePeRoutes);
app.use('/api/admin', adminRoutes);



// ...

// Auth Routes
app.post('/api/upload', upload.single('image'), (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ message: 'No file uploaded' });
        }
        // Return the full URL to the uploaded file
        // In production, use process.env.BASE_URL. For local:
        const imageUrl = `${req.protocol}://${req.get('host')}/uploads/${req.file.filename}`;
        res.json({ imageUrl });
    } catch (err) {
        res.status(500).json({ message: 'Error uploading file' });
    }
});

app.post('/api/auth/register', async (req, res) => {
    try {
        const { name, email, password } = req.body;
        const user = new User({ name, email, password });
        await user.save();
        res.status(201).json({ message: 'User registered successfully' });
    } catch (err) {
        res.status(400).json({ message: 'Error registering user', error: err.message });
    }
});

app.post('/api/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await User.findOne({ email, password });
        if (!user) return res.status(401).json({ message: 'Invalid credentials' });

        const token = jwt.sign(
            { id: user._id, email: user.email },
            process.env.JWT_SECRET || 'fallback_secret_for_demo',
            { expiresIn: '1h' }
        );

        res.json({
            message: 'Login successful',
            user: { name: user.name, email: user.email, role: user.role },
            token
        });
    } catch (err) {
        console.error("Login Error:", err);
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});

app.post('/api/auth/forgot-password', async (req, res) => {
    res.json({ message: 'Password reset link sent to email' });
});

// Contact Route
app.post('/api/contact', async (req, res) => {
    try {
        const contact = new Contact(req.body);
        await contact.save();
        res.status(201).json({ message: 'Message received!' });
    } catch (err) {
        res.status(400).json({ message: 'Error sending message' });
    }
});

// Book Routes
app.get('/api/books', async (req, res) => {
    try {
        const books = await Book.find();
        res.json(books);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

app.post('/api/books', async (req, res) => {
    try {
        const count = await Book.countDocuments();
        const newBook = new Book({
            ...req.body,
            id: count + 1 + Date.now()
        });
        const savedBook = await newBook.save();
        res.status(201).json(savedBook);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Payment Routes
app.post('/api/payment/create-payment-intent', authMiddleware, async (req, res) => {
    try {
        const { items } = req.body;
        if (!items || !items.length) return res.status(400).json({ message: 'No items provided' });

        let totalAmount = 0;
        for (const item of items) {
            const book = await Book.findOne({ id: item.id });
            if (!book) return res.status(404).json({ message: `Book ${item.id} not found` });
            totalAmount += book.price * (item.quantity || 1);
        }

        if (totalAmount < 1) return res.status(400).json({ message: "Invalid amount" });

        const paymentIntent = await stripe.paymentIntents.create({
            amount: totalAmount * 100,
            currency: "inr",
            automatic_payment_methods: { enabled: true },
            metadata: { userId: req.user.id }
        });

        res.send({ clientSecret: paymentIntent.client_secret });
    } catch (err) {
        console.error("Stripe Error:", err);
        res.status(500).json({ message: 'Payment init failed' });
    }
});

app.post('/api/payment/save-order', authMiddleware, async (req, res) => {
    try {
        const { paymentIntentId, items, paymentMethod, shippingDetails } = req.body;
        let status = 'Paid';
        let paymentId = paymentIntentId;

        if (paymentMethod !== 'COD') {
            const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
            if (paymentIntent.status !== 'succeeded') return res.status(400).json({ message: "Payment failed" });
            paymentId = paymentIntent.id;
        } else {
            status = 'Placed';
            paymentId = 'COD_' + Date.now();
        }

        let totalAmount = 0;
        const orderItems = [];
        for (const item of items) {
            const book = await Book.findOne({ id: item.id });
            if (book) {
                totalAmount += book.price * (item.quantity || 1);
                orderItems.push({
                    bookId: book.id,
                    title: book.title,
                    quantity: item.quantity || 1,
                    price: book.price
                });
            }
        }

        const newOrder = new Order({
            user: req.user.id,
            items: orderItems,
            totalAmount,
            paymentId,
            status,
            paymentMethod: paymentMethod || 'Stripe',
            shippingDetails
        });

        await newOrder.save();
        res.json({ success: true, message: 'Order Saved', orderId: newOrder._id });
    } catch (err) {
        console.error("Save Order Error:", err);
        res.status(500).json({ message: 'Error saving order' });
    }
});

app.get('/api/orders', authMiddleware, async (req, res) => {
    try {
        const orders = await Order.find({ user: req.user.id }).sort({ createdAt: -1 });
        res.json(orders);
    } catch (err) {
        res.status(500).json({ message: 'Error fetching orders' });
    }
});

app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
});
